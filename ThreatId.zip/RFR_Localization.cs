﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.ML.OnnxRuntime;
using Microsoft.ML.OnnxRuntime.Tensors;

namespace Listen_N
{
    // Diagnostic status codes for localization
    public enum LocalizationStatus
    {
        Success,
        InsufficientCounts,
        DetectorFault,
        OutOfDistribution,
        HighUncertainty,
        MultiSourceAmbiguous
    }

    // Structured output object
    public class LocalizationResult
    {
        public bool Success { get; set; }
        public double X { get; set; }
        public double Y { get; set; }
        public double Z { get; set; }
        public double Uncertainty { get; set; }
        public LocalizationStatus StatusCode { get; set; }
        public double M1 { get; set; }
        public double M2 { get; set; }
        public double Yhat { get; set; }
        public double R1 { get; set; }
        public double R2 { get; set; }
        public string Message { get; set; }
    }

    // Core Random Forest Regression Localization
    public sealed class RfrLocalization : IDisposable
    {
        private readonly int M = 15;     // Number of tubes
        private readonly int Nmin;       // Minimum total counts required
        private readonly double Dmax;    // Mahalanobis distance threshold
        private readonly double SigmaMax;// Maximum tolerated uncertainty

        private readonly InferenceSession _session;
        private readonly double[] mu;        // Training mean vector
        private readonly double[,] invCov;   // Inverse covariance matrix

        public RfrLocalization(
            string modelPath,
            double[] meanVector,
            double[,] inverseCovariance,
            int nmin = 500,
            double dmax = 5.0,
            double sigmaMax = 0.5)
        {
            Nmin = nmin;
            Dmax = dmax;
            SigmaMax = sigmaMax;
            mu = meanVector;
            invCov = inverseCovariance;
            _session = new InferenceSession(modelPath);
        }

        public void Dispose()
        {
            _session?.Dispose();
        }

        public LocalizationResult Localize(
            int[] tubeCounts,
            bool overrideLowCounts,
            double m1, double m2, double yhat, double r1, double r2)
        {
            var result = new LocalizationResult
            {
                Success = false,
                M1 = m1,
                M2 = m2,
                Yhat = yhat,
                R1 = r1,
                R2 = r2
            };

            int N = tubeCounts.Sum();

            // Step 2. Count sufficiency
            if (N < Nmin && !overrideLowCounts)
            {
                result.StatusCode = LocalizationStatus.InsufficientCounts;
                result.Message = "Counts below threshold, localization suppressed.";
                return result;
            }

            // Step 2b. Normalize counts
            double[] f = tubeCounts.Select(c => (double)c / Math.Max(N, 1)).ToArray();

            // Step 3. Detector health check
            if (tubeCounts.Count(c => c == 0) > 1)
            {
                result.StatusCode = LocalizationStatus.DetectorFault;
                result.Message = "Multiple tubes inactive, possible hardware fault.";
                return result;
            }

            // Step 2c. Build features (raw + engineered)
            double[] features = BuildFeatures(f);

            // Step 4. Out-of-distribution check
            double dm = ComputeMahalanobis(features);
            if (dm > Dmax)
            {
                result.StatusCode = LocalizationStatus.OutOfDistribution;
                result.Message = $"Feature vector lies outside training distribution (DM={dm:F2}).";
                return result;
            }

            // Step 5. Predict with Random Forest
            (double x, double y, double z, double sigma) = PredictWithRandomForest(features);

            // Step 6. Uncertainty gating
            if (sigma > SigmaMax)
            {
                result.StatusCode = LocalizationStatus.HighUncertainty;
                result.Message = $"Prediction uncertainty exceeds threshold (σ={sigma:F2}).";
                return result;
            }

            // Step 7. Multi-source ambiguity (placeholder)
            if (CheckMultiSourceResidual(features, (x, y, z)))
            {
                result.StatusCode = LocalizationStatus.MultiSourceAmbiguous;
                result.Message = "Observed pattern inconsistent with any single-source model.";
                return result;
            }

            // Step 8. Success with multiplicity tagging
            result.Success = true;
            result.StatusCode = LocalizationStatus.Success;
            result.X = x;
            result.Y = y;
            result.Z = z;
            result.Uncertainty = sigma;
            result.Message = "Localization successful.";
            return result;
        }

        // --- Feature Construction ---
        private double[] BuildFeatures(double[] f)
        {
            var feats = new List<double>(f);

            // Pairwise differences
            for (int i = 0; i < M; i++)
                for (int j = i + 1; j < M; j++)
                    feats.Add(f[i] - f[j]);

            // Row ratios (assuming tube layout: front=0–6, mid=7–12, back=13–14)
            double front = f.Take(7).Sum();
            double mid = f.Skip(7).Take(6).Sum();
            double back = f.Skip(13).Take(2).Sum();
            feats.Add(front / Math.Max(mid, 1e-9));
            feats.Add(front / Math.Max(back, 1e-9));

            return feats.ToArray();
        }

        // --- Mahalanobis distance check ---
        private double ComputeMahalanobis(double[] features)
        {
            double[] diff = features.Zip(mu, (f, m) => f - m).ToArray();
            double[] temp = new double[diff.Length];

            for (int i = 0; i < diff.Length; i++)
            {
                double sum = 0;
                for (int j = 0; j < diff.Length; j++)
                    sum += invCov[i, j] * diff[j];
                temp[i] = sum;
            }

            double dot = 0;
            for (int i = 0; i < diff.Length; i++)
                dot += diff[i] * temp[i];

            return Math.Sqrt(dot);
        }

        // --- RF prediction via ONNX ---
        private (double, double, double, double) PredictWithRandomForest(double[] features)
        {
            var input = new DenseTensor<float>(new[] { 1, features.Length });
            for (int i = 0; i < features.Length; i++)
                input[0, i] = (float)features[i];

            var inputs = new List<NamedOnnxValue>
            {
                NamedOnnxValue.CreateFromTensor("float_input", input)
            };

            using var results = _session.Run(inputs);
            var preds = results.First().AsEnumerable<float>().ToArray();

            // Assume ONNX model outputs [x, y, z]
            double x = preds[0];
            double y = preds[1];
            double z = preds[2];

            // Placeholder for uncertainty: could use RF quantile regression, or an ensemble variance estimate
            double sigma = 0.2;

            return (x, y, z, sigma);
        }

        // --- Multi-source ambiguity check (stub for now) ---
        private bool CheckMultiSourceResidual(double[] features, (double x, double y, double z) pred)
        {
            // TODO: implement residual comparison to expected single-source patterns
            return false;
        }
    }
}
